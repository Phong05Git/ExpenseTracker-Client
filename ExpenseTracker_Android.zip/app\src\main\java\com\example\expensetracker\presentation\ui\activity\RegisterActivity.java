package com.example.expensetracker.presentation.ui.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.example.expensetracker.R;
import com.example.expensetracker.domain.common.Resource;
import com.example.expensetracker.presentation.viewmodel.RegisterViewModel;
import com.example.expensetracker.util.ValidationUtils;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import dagger.hilt.android.AndroidEntryPoint;

import android.util.Log;

import java.net.InetSocketAddress;
import java.net.Socket;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.util.Log;

import java.net.InetSocketAddress;
import java.net.Socket;

@AndroidEntryPoint
public final class RegisterActivity extends AppCompatActivity {
    private RegisterViewModel registerViewModel;

    private TextInputLayout fullNameLayout;
    private TextInputLayout usernameLayout;
    private TextInputLayout emailLayout;
    private TextInputLayout passwordLayout;
    private TextInputLayout confirmPasswordLayout;

    private TextInputEditText editFullName;
    private TextInputEditText editUsername;
    private TextInputEditText editEmail;
    private TextInputEditText editPassword;
    private TextInputEditText editConfirmPassword;

    private MaterialButton buttonRegister;
    private TextView textLogin;

    @Override
    protected void onCreate(
            Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        logNetworkInformation();
        testBackendTcpConnection();

        setContentView(R.layout.activity_register);

        if (com.example.expensetracker.BuildConfig.DEBUG) {
            testTcpConnection();
        }

        initializeViews();

        registerViewModel =
                new ViewModelProvider(this)
                        .get(RegisterViewModel.class);

        setupLoginText();
        setupListeners();
        observeRegister();
    }

    private void initializeViews() {
        fullNameLayout =
                findViewById(R.id.fullNameLayout);

        usernameLayout =
                findViewById(R.id.usernameLayout);

        emailLayout =
                findViewById(R.id.emailLayout);

        passwordLayout =
                findViewById(R.id.passwordLayout);

        confirmPasswordLayout =
                findViewById(
                        R.id.confirmPasswordLayout);

        editFullName =
                findViewById(R.id.editFullName);

        editUsername =
                findViewById(R.id.editUsername);

        editEmail =
                findViewById(R.id.editEmail);

        editPassword =
                findViewById(R.id.editPassword);

        editConfirmPassword =
                findViewById(R.id.editConfirmPassword);

        buttonRegister =
                findViewById(R.id.buttonRegister);

        textLogin =
                findViewById(R.id.textLogin);
    }

    private void setupListeners() {
        buttonRegister.setOnClickListener(
                view -> performRegister());

        textLogin.setOnClickListener(
                view -> openLogin());

        ValidationUtils.bindLiveValidation(editFullName, fullNameLayout,
                () -> ValidationUtils.fullNameError(getText(editFullName)));
        ValidationUtils.bindLiveValidation(editUsername, usernameLayout,
                () -> ValidationUtils.usernameError(getText(editUsername)));
        ValidationUtils.bindLiveValidation(editEmail, emailLayout,
                () -> ValidationUtils.emailError(getText(editEmail)));
        ValidationUtils.bindLiveValidation(editPassword, passwordLayout,
                () -> ValidationUtils.passwordError(getText(editPassword)));
        ValidationUtils.bindLiveValidation(editConfirmPassword, confirmPasswordLayout,
                () -> ValidationUtils.confirmPasswordError(getText(editPassword), getText(editConfirmPassword)));
    }

    private void setupLoginText() {
        String text =
                "Đã có tài khoản? Đăng nhập";

        SpannableString spannableString =
                new SpannableString(text);

        int start =
                text.indexOf("Đăng nhập");

        spannableString.setSpan(
                new ForegroundColorSpan(
                        getColor(
                                R.color.primary_green)),
                start,
                text.length(),
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        textLogin.setText(spannableString);
    }

    private void performRegister() {
        boolean valid = ValidationUtils.setError(fullNameLayout, ValidationUtils.fullNameError(getText(editFullName)));
        valid &= ValidationUtils.setError(usernameLayout, ValidationUtils.usernameError(getText(editUsername)));
        valid &= ValidationUtils.setError(emailLayout, ValidationUtils.emailError(getText(editEmail)));
        valid &= ValidationUtils.setError(passwordLayout, ValidationUtils.passwordError(getText(editPassword)));
        valid &= ValidationUtils.setError(confirmPasswordLayout,
                ValidationUtils.confirmPasswordError(getText(editPassword), getText(editConfirmPassword)));

        if (!valid) return;

        registerViewModel.register(
                getText(editFullName),
                getText(editUsername),
                getText(editPassword),
                getText(editConfirmPassword),
                getText(editEmail));
    }

    private String getText(
            TextInputEditText editText) {
        if (editText.getText() == null) {
            return "";
        }

        return editText.getText().toString();
    }

    private void observeRegister() {
        registerViewModel
                .getRegisterState()
                .observe(
                        this,
                        resource -> {
                            if (resource == null) {
                                return;
                            }

                            switch (resource.getStatus()) {
                                case LOADING:
                                    setRegisterEnabled(false);
                                    break;

                                case SUCCESS:
                                    setRegisterEnabled(true);
                                    openLoginAfterRegister();
                                    break;

                                case ERROR:
                                    setRegisterEnabled(true);
                                    showRegisterError(
                                            resource.getMessage());
                                    break;

                                case IDLE:
                                default:
                                    setRegisterEnabled(true);
                                    break;
                            }
                        });
    }

    private void showRegisterError(
            String message) {
        if (message == null ||
                message.isBlank()) {
            message = "Đăng ký thất bại.";
        }

        if (message.contains("họ và tên")) {
            fullNameLayout.setError(message);
            return;
        }

        if (message.contains("tên đăng nhập")) {
            usernameLayout.setError(message);
            return;
        }

        if (message.contains("email") ||
                message.contains("Email")) {
            emailLayout.setError(message);
            return;
        }

        if (message.contains("mật khẩu xác nhận")) {
            confirmPasswordLayout.setError(message);
            return;
        }

        if (message.contains("Mật khẩu")) {
            passwordLayout.setError(message);
            return;
        }

        Toast.makeText(
                        this,
                        message,
                        Toast.LENGTH_LONG)
                .show();
    }

    private void setRegisterEnabled(
            boolean enabled) {
        buttonRegister.setEnabled(enabled);
        editFullName.setEnabled(enabled);
        editUsername.setEnabled(enabled);
        editEmail.setEnabled(enabled);
        editPassword.setEnabled(enabled);
        editConfirmPassword.setEnabled(enabled);
    }

    private void openLogin() {
        Intent intent =
                new Intent(
                        this,
                        LoginActivity.class);

        startActivity(intent);
        finish();
    }

    private void openLoginAfterRegister() {
        Intent intent =
                new Intent(
                        this,
                        LoginActivity.class);

        intent.putExtra(
                "register_success",
                true);

        intent.putExtra(
                "registered_username",
                getText(editUsername));

        intent.addFlags(
                Intent.FLAG_ACTIVITY_CLEAR_TOP);

        startActivity(intent);
        finish();
    }

    private void testTcpConnection() {
        new Thread(() -> {
            try (Socket socket = new Socket()) {
                socket.connect(
                        new InetSocketAddress("10.0.2.2", 5080),
                        5000
                );

                Log.i(
                        "NetworkProbe",
                        "TCP CONNECTED: " + socket.isConnected()
                );

            } catch (Exception exception) {
                Log.e(
                        "NetworkProbe",
                        "TCP CONNECTION FAILED",
                        exception
                );
            }
        }).start();
    }

    /**
     * Kiểm tra Network mà Android App Process đang sử dụng.
     */
    private void logNetworkInformation() {

        Log.i("NetworkProbe", "========== NETWORK INFORMATION ==========");

        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        if (cm == null) {
            Log.e("NetworkProbe", "ConnectivityManager is NULL");
            return;
        }

        Network activeNetwork = cm.getActiveNetwork();

        Log.i("NetworkProbe", "ACTIVE_NETWORK = " + activeNetwork);

        Network processNetwork = cm.getBoundNetworkForProcess();

        Log.i("NetworkProbe", "PROCESS_BOUND_NETWORK = " + processNetwork);

        if (activeNetwork == null) {
            Log.e("NetworkProbe", "No active network available");
            return;
        }

        NetworkCapabilities capabilities =
                cm.getNetworkCapabilities(activeNetwork);

        LinkProperties linkProperties =
                cm.getLinkProperties(activeNetwork);

        Log.i("NetworkProbe", "CAPABILITIES = " + capabilities);
        Log.i("NetworkProbe", "LINK_PROPERTIES = " + linkProperties);

        if (capabilities != null) {

            Log.i("NetworkProbe", "HAS_INTERNET = "
                    + capabilities.hasCapability(
                    NetworkCapabilities.NET_CAPABILITY_INTERNET));

            Log.i("NetworkProbe", "IS_VALIDATED = "
                    + capabilities.hasCapability(
                    NetworkCapabilities.NET_CAPABILITY_VALIDATED));

            Log.i("NetworkProbe", "IS_WIFI = "
                    + capabilities.hasTransport(
                    NetworkCapabilities.TRANSPORT_WIFI));

            Log.i("NetworkProbe", "IS_CELLULAR = "
                    + capabilities.hasTransport(
                    NetworkCapabilities.TRANSPORT_CELLULAR));

            Log.i("NetworkProbe", "IS_VPN = "
                    + capabilities.hasTransport(
                    NetworkCapabilities.TRANSPORT_VPN));
        }

        Log.i("NetworkProbe", "=========================================");
    }


    /**
     * Kiểm tra TCP trực tiếp từ Android App Process
     * đến ASP.NET Core Backend.
     */
    private void testBackendTcpConnection() {

        new Thread(() -> {

            Log.i("NetworkProbe", "========== TCP CONNECTION TEST ==========");

            String host = "10.0.2.2";
            int port = 5080;
            int timeout = 5000;

            try (Socket socket = new Socket()) {

                socket.connect(
                        new InetSocketAddress(host, port),
                        timeout
                );

                Log.i(
                        "NetworkProbe",
                        "TCP CONNECTION SUCCESS: "
                                + socket.getInetAddress()
                                + ":"
                                + socket.getPort()
                );

            } catch (Exception e) {

                Log.e(
                        "NetworkProbe",
                        "TCP CONNECTION FAILED",
                        e
                );

            }

            Log.i("NetworkProbe", "==========================================");

        }).start();
    }
}
