plugins {
    id("com.android.application") version "9.2.1" apply false
    id("com.google.dagger.hilt.android") version "2.59.2" apply false
}